//============================================================================
//
//  This file is part of GPSTk, the GPS Toolkit.
//
//  The GPSTk is free software; you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published
//  by the Free Software Foundation; either version 3.0 of the License, or
//  any later version.
//
//  The GPSTk is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with GPSTk; if not, write to the Free Software Foundation,
//  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
//  
//  Copyright 2004, The University of Texas at Austin
//  kaifa Kuang - Wuhan University . 2016
//
//============================================================================

//============================================================================
//
//This software developed by Applied Research Laboratories at the University of
//Texas at Austin, under contract to an agency or agencies within the U.S. 
//Department of Defense. The U.S. Government retains all rights to use,
//duplicate, distribute, disclose, or release this software. 
//
//Pursuant to DoD Directive 523024 
//
// DISTRIBUTION STATEMENT A: This software has been approved for public 
//                           release, distribution is unlimited.
//
//=============================================================================

/**
* @file EarthOceanTide.cpp
* 
*/

#include "EarthOceanTide.hpp"
#include "GNSSconstants.hpp"
#include "StringUtils.hpp"
#include "MJD.hpp"
#include "Legendre.hpp"


using namespace std;
using namespace gpstk::StringUtils;


namespace gpstk
{

   // Load Ocean Tide file
   void EarthOceanTide::loadFile(const string& file)
      throw(FileMissingException)
   {
      ifstream inpf(file.c_str());

      if(!inpf)
      {
         FileMissingException fme("Could not open Ocean Tide file " + file);
         GPSTK_THROW(fme);
      }

      // First, file header
      string temp;
      for(int i=0; i<4; ++i)
         getline(inpf,temp);

      bool ok(true);

      string line;
      // Then, file data
      while( !inpf.eof() && inpf.good() )
      {
         getline(inpf,line);
         stripTrailing(line,'\r');

         if( inpf.eof() ) break;

         if( inpf.bad() ) { ok = false; break; }

         OceanTideData data;
         // Doodson number, coded into Doodson variable multipliers
         data.n[0]   =  asInt( line.substr(0,1) );
         data.n[1]   =  asInt( line.substr(1,1) ) - 5;
         data.n[2]   =  asInt( line.substr(2,1) ) - 5;
         data.n[3]   =  asInt( line.substr(4,1) ) - 5;
         data.n[4]   =  asInt( line.substr(5,1) ) - 5;
         data.n[5]   =  asInt( line.substr(6,1) ) - 5;
         // Darwin's symbol
         data.Darw   =  line.substr(8,3);
         // Degree, Order
         data.l      =  asInt( line.substr(12,3) );
         data.m      =  asInt( line.substr(16,3) );

         // Coefficients
         data.DelCp  =  asDouble( line.substr(21,8) )*1e-12;
         data.DelSp  =  asDouble( line.substr(31,8) )*1e-12;
         data.DelCm  =  asDouble( line.substr(43,8) )*1e-12;
         data.DelSm  =  asDouble( line.substr(53,8) )*1e-12;

         if(data.l <= desiredDegree)
         {
            otDataVec.push_back(data);
         }
         else
         {
            continue;
         }

      }

      inpf.close();

      if( !ok )
      {
         FileMissingException fme("Ocean Tide file " + file + " is corrupted or in wrong format.");
         GPSTK_THROW(fme);
      }

   }  // End of method "EarthOceanTide::loadOceanTideFile()"


      /* Ocean pole tide to normalized earth potential coefficients
       *
       * @param utc     time in UTC
       * @param dC      Correction to normalized coefficients dC
       * @param dS      Correction to normalized coefficients dS
       */
   void EarthOceanTide::getOceanTide(CommonTime utc, Matrix<double>& CS)
   {
      // TT
      CommonTime tt( pRefSys->UTC2TT(utc) );

      // UT1
      CommonTime ut1( pRefSys->UTC2UT1(utc) );

      // Doodson arguments
      double BETA[6] = {0.0};
      double FNUT[5] = {0.0};

      pRefSys->DoodsonArguments(ut1, tt, BETA, FNUT);


      vector<OceanTideData>::iterator itr;
      for(itr=otDataVec.begin(); itr!=otDataVec.end(); ++itr)
      {
         // theta_f
         double theta_f = (*itr).n[0]*BETA[0] + (*itr).n[1]*BETA[1]
                        + (*itr).n[2]*BETA[2] + (*itr).n[3]*BETA[3]
                        + (*itr).n[4]*BETA[4] + (*itr).n[5]*BETA[5];

         // sine and cosine of theta_f
         double stf = std::sin(theta_f);
         double ctf = std::cos(theta_f);

         // index
         int id;
         id = indexTranslator((*itr).l, (*itr).m);

         // corrections
         CS(id-1, 0) += ((*itr).DelCp + (*itr).DelCm)*ctf
                      + ((*itr).DelSp + (*itr).DelSm)*stf;
         CS(id-1, 1) += ((*itr).DelSp - (*itr).DelSm)*ctf
                      - ((*itr).DelCp - (*itr).DelCm)*stf;

      }  // End of 'for()'
      
   }	// End of method 'EarthOceanTide::getOceanTide()'


}  // End of namespace 'gpstk'
